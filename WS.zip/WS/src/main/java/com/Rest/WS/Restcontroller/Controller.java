package com.Rest.WS.Restcontroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	@GetMapping("/Hello")
	public String helloWorld() {
		return "HelloWorld";
	}
}
