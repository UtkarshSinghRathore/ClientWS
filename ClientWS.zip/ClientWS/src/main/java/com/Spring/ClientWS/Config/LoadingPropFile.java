package com.Spring.ClientWS.Config;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Configuration
@PropertySource(value = "classpath:config.properties")
public class LoadingPropFile {

	@Value("${API1_url}")
	public String API1_URL;
	
	@Value("${API2_url}")
	public String API2_URL;
	
	@Value("${API3_url}")
	public String API3_url;

}

