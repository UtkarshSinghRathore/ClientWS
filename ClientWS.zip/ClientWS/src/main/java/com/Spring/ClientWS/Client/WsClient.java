package com.Spring.ClientWS.Client;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;

import com.Spring.ClientWS.BindingClasses.Acknowledgement;
import com.Spring.ClientWS.BindingClasses.CustomerRequest;
import com.Spring.ClientWS.BindingClasses.GetCountryRequest;
import com.Spring.ClientWS.BindingClasses.GetCountryResponse;
import com.Spring.ClientWS.Config.LoadingPropFile;
import com.Spring.ClientWS.TimeCheck.TimeCheck;
import com.Spring.ClientWS.TimeCheck.TimeCheckAPI2;
import com.Spring.ClientWS.TimeCheck.TimeCheckAPI3;

public class WsClient {

	@Autowired
	private RestTemplate RestTemplate;

	@Autowired
	TimeCheck timeCheck;

	@Autowired
	private Jaxb2Marshaller marshaller;

	@Autowired(required = true)
	private CustomerRequest request;

	@Autowired
	private TimeCheckAPI2 timeCheckAPI2;

	@Autowired
	private GetCountryRequest CountryRequest;

	@Autowired
	WebServiceTemplate webServiceTemplate;

	@Autowired
	LoadingPropFile prop;
	
	@Autowired
	private TimeCheckAPI3 timeCheckAPI3;

	public int StatusCodeAPI1, StatusCodeAPI2, StatusCodeAPI3;

	public void invokeClient() {

		try {

			Acknowledgement acknowledgement = (Acknowledgement) webServiceTemplate.marshalSendAndReceive(prop.API1_URL,
					request);
			StatusCodeAPI1 = 200;

		} catch (Exception e) {
			StatusCodeAPI1 = 404;

		}
		try {
			GetCountryResponse response = (GetCountryResponse) webServiceTemplate.marshalSendAndReceive(prop.API2_URL,
					CountryRequest);
			StatusCodeAPI2 = 200;

		} catch (Exception e) {
			StatusCodeAPI2 = 404;
		}
		try {
			String Response = RestTemplate.getForObject(prop.API3_url, String.class);

			StatusCodeAPI3 = 200;
		} catch (Exception e) {
			StatusCodeAPI3 = 404;

		}
		timeCheck.timeCheck();
		timeCheckAPI2.timeCheckAPI2();
		timeCheckAPI3.timeCheckAPI3();

	}

}
