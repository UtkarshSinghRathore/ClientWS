package com.Spring.ClientWS.ModelClasses;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ApisNames {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;

	private String ApiName;
	private String Service;
	private String Endpoint;
	private String Type;

	@Column(length = 1000000)
	private String Request;

	private int ResponseCode;
	@Column(length = 1000000)
	private String Response;

	private String RequestType;
	private Date Last_Uptime;
	private Date Last_DownTime;

	public Date getLast_Uptime() {
		return Last_Uptime;
	}

	public void setLast_Uptime(Date last_Uptime) {
		Last_Uptime = last_Uptime;
	}

	public Date getLast_DownTime() {
		return Last_DownTime;
	}

	public void setLast_DownTime(Date last_DownTime) {
		Last_DownTime = last_DownTime;
	}

	public String getRequestType() {
		return RequestType;
	}

	public void setRequestType(String requestType) {
		RequestType = requestType;
	}

	public String getResponse() {
		return Response;
	}

	public void setResponse(String response) {
		Response = response;
	}

	public int getResponseCode() {
		return ResponseCode;
	}

	public void setResponseCode(int responseCode) {
		ResponseCode = responseCode;
	}

	public String getRequest() {
		return Request;
	}

	public void setRequest(String request) {
		Request = request;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getEndpoint() {
		return Endpoint;
	}

	public void setEndpoint(String endpoint) {
		Endpoint = endpoint;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getApiName() {
		return ApiName;
	}

	public void setApiName(String apiName) {
		ApiName = apiName;
	}

	public String getService() {
		return Service;
	}

	public void setService(String service) {
		Service = service;
	}

}
