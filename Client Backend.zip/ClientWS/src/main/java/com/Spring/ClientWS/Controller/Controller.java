package com.Spring.ClientWS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Spring.ClientWS.Client.WsClient;
import com.Spring.ClientWS.ModelClasses.ApisNames;
import com.Spring.ClientWS.Service.ApiService;

import com.Spring.ClientWS.TimePercentage.UpTimePercent;
import com.Spring.ClientWS.TimeRepository.ApisNamesRepo;
import com.Spring.ClientWS.TimeRepository.TimeRepository;

@RestController
@RequestMapping("/apis")
@CrossOrigin("*")
public class Controller {

	
	@Autowired
	ApisNamesRepo apiRepo;
	
	@Autowired
	WsClient client;
	@Autowired
	TimeRepository repo;
	@Autowired
	UpTimePercent upTimePercent;
	@Autowired
	ApiService service;
	
	

	@GetMapping("/showApis")
	public ResponseEntity<List<ApisNames>> getAllApis(){
		List<ApisNames> list = service.getAllApis();
		
		return new ResponseEntity<List<ApisNames>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	@GetMapping("/{id}")
	public ResponseEntity<ApisNames> getApiById(@PathVariable("id") int id) throws Exception{
		
		ApisNames api = service.getApisNameById(id);
		
		return new ResponseEntity<ApisNames>(api, new HttpHeaders(), HttpStatus.OK);
	}
	@PostMapping
	public ResponseEntity<ApisNames> createOrupdateApi(@RequestBody ApisNames api){
		ApisNames Updatedapi = service.createorUpdateApis(api);
		
		return new ResponseEntity<ApisNames>(Updatedapi, new HttpHeaders(), HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public HttpStatus deleteApibyId(@PathVariable("id") int id) throws Exception {
		service.deleteApiById(id);
		return HttpStatus.FORBIDDEN;
	}
	
}
