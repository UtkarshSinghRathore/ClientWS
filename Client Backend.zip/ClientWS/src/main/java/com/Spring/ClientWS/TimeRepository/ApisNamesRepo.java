package com.Spring.ClientWS.TimeRepository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Spring.ClientWS.ModelClasses.ApisNames;

@Repository
public interface ApisNamesRepo extends CrudRepository<ApisNames, Integer> {

}
