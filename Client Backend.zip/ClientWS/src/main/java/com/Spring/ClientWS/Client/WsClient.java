package com.Spring.ClientWS.Client;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;

import com.Spring.ClientWS.BindingClasses.Acknowledgement;
import com.Spring.ClientWS.BindingClasses.CustomerRequest;
import com.Spring.ClientWS.BindingClasses.GetCountryRequest;
import com.Spring.ClientWS.BindingClasses.GetCountryResponse;
import com.Spring.ClientWS.Config.LoadingPropFile;
import com.Spring.ClientWS.Config.ValidatePropertyFile;
import com.Spring.ClientWS.ModelClasses.ApisNames;
import com.Spring.ClientWS.Service.ApiService;

public class WsClient {

	@Autowired
	private RestTemplate RestTemplate;

	@Autowired
	private GetCountryRequest CountryRequest;

	@Autowired
	WebServiceTemplate webServiceTemplate;

	@Autowired
	LoadingPropFile prop;

	@Autowired
	ValidatePropertyFile validatePropertyFile;

//	/ublic int StatusCodeAPI1, StatusCodeAPI2, StatusCodeAPI3, statusCodeGetLimitRestApi,
//			statusCodeCreasteSessionRestApi;

	@Autowired
	ApiService api_service;

	synchronized public void invokeClient() throws Exception {

		// FOR SOAP SERVICES

		// Returning List with Duplicate Values
		List<ApisNames> SoapListwithDuplicates = api_service.getSoapServices();

		// Converting List without Duplicacy
		List<ApisNames> SoapList = SoapListwithDuplicates.stream().distinct().collect(Collectors.toList());
		
		//For Loop For SoapList
		for (int i = 0; i < SoapList.size(); i++) {
			try {
				// Establishing URL for Endpoint
				URL url = new URL(SoapList.get(i).getEndpoint());
				// Establishing Connection
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setDoOutput(true);
				connection.setUseCaches(true);

				// Setting Request Type
				connection.setRequestMethod(SoapList.get(i).getType().toUpperCase());

				// Setting Headers Such as Content Type
				connection.setRequestProperty("Content-Type", "text/xml");

				// write XML Request
				OutputStream outputStream = connection.getOutputStream();
				byte[] b = SoapList.get(i).getRequest().getBytes("UTF-8");
				outputStream.write(b);
				outputStream.flush();
				outputStream.close();

				// Read XML Response
				InputStream input = connection.getInputStream();
				byte[] res = new byte[2048];
				int j = 0;
				StringBuilder response = new StringBuilder();
				while ((j = input.read(res)) != -1) {
					response.append(new String(res, 0, j));
				}
				input.close();

				// Setting Updated Api Response and its Code
				ApisNames UpdatedApi = SoapList.get(i);
				UpdatedApi.setResponse(response.toString());
				UpdatedApi.setResponseCode(connection.getResponseCode());
				api_service.createorUpdateApis(UpdatedApi);

				// Saving the api in the Database
				api_service.createorUpdateApis(UpdatedApi);

				// Setting Last Uptime And Last Downtime in the Database
				api_service.UpdateLastTime(SoapList.get(i));

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			// FOR REST SERVICES

			// Rest List With Duplicate Values
			List<ApisNames> RestListWithDuplicates = api_service.getRestServices();

			// Rest List Without Duplicacy
			List<ApisNames> RestList = RestListWithDuplicates.stream().distinct().collect(Collectors.toList());
			
			
			//For Loop For RestList
			for(int i=0; i<RestList.size();i++) {
			try {
				
				URL url = new URL(RestList.get(i).getEndpoint());
				// Establishing Connection
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setDoOutput(true);
				connection.setUseCaches(true);

				// Checking the Request Type GET OR POST
				if (RestList.get(i).getType().equalsIgnoreCase("Get")) {
					connection.setRequestMethod(RestList.get(i).getType().toUpperCase());

					// Setting Headers Such as Content Type
					connection.setRequestProperty("Content-Type", "application/json");

					// Read JSON Response
					InputStream input = connection.getInputStream();
					byte[] res = new byte[2048];
					int j = 0;
					StringBuilder response = new StringBuilder();
					while ((j = input.read(res)) != -1) {
						response.append(new String(res, 0, j));
					}
					input.close();
					// Setting Updated Api Response and its Code
					ApisNames UpdatedApi = RestList.get(i);
					UpdatedApi.setResponse(response.toString());
					UpdatedApi.setResponseCode(connection.getResponseCode());
					api_service.createorUpdateApis(UpdatedApi);

					// Saving the api in the Database
					api_service.createorUpdateApis(UpdatedApi);

					// Setting Last Uptime And Last Downtime in the Database
					api_service.UpdateLastTime(RestList.get(i));

				}
				//Checking the Request Type
				if(RestList.get(i).getType().equalsIgnoreCase("Post")) {
					connection.setRequestMethod(RestList.get(i).getType().toUpperCase());

					connection.setRequestMethod(RestList.get(i).getRequestType().toUpperCase());
					
					// Setting Headers Such as Content Type
					connection.setRequestProperty("Content-Type", "application/json");
					
					//Writes JSON Request
					OutputStream outputStream = connection.getOutputStream();
					byte[] b = RestList.get(i).getRequest().getBytes("UTF-8");
					outputStream.write(b);
					outputStream.flush();
					outputStream.close();
					
					// Read JSON Response
					InputStream input = connection.getInputStream();
					byte[] res = new byte[2048];
					int j = 0;
					StringBuilder response = new StringBuilder();
					while ((j = input.read(res)) != -1) {
						response.append(new String(res, 0, j));
					}
					input.close();
					// Setting Updated Api Response and its Code
					ApisNames UpdatedApi = RestList.get(i);
					UpdatedApi.setResponse(response.toString());
					UpdatedApi.setResponseCode(connection.getResponseCode());
					api_service.createorUpdateApis(UpdatedApi);

					// Saving the api in the Database
					api_service.createorUpdateApis(UpdatedApi);

					// Setting Last Uptime And Last Downtime in the Database
					api_service.UpdateLastTime(RestList.get(i));
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			}

		}

//	
//		try {
//			ResponseEntity<String> responseHelloWorld= RestTemplate.getForEntity(prop.API3_url, String.class);
//
//			StatusCodeAPI3 = responseHelloWorld.getStatusCodeValue();
//		} catch (Exception e) {
//			StatusCodeAPI3 = 404;
//
//		}
//
//		// calling Get Limit rest api
//		try {
//
//			ResponseEntity<String> responseGetLimit =RestTemplate.getForEntity(prop.app1_service1_rest, String.class );
//			statusCodeGetLimitRestApi=responseGetLimit.getStatusCodeValue();
//		} catch (Throwable e) {
//			e.printStackTrace();
//			statusCodeGetLimitRestApi = 404;
//		}
//
//		// calling Create Session rest api
//		try {
//
//			ResponseEntity<String> responseCreateSession =RestTemplate.getForEntity(prop.app1_service2_rest, String.class );
//			statusCodeCreasteSessionRestApi=responseCreateSession.getStatusCodeValue();
//		} catch (Throwable e) {
//			e.printStackTrace();
//			statusCodeCreasteSessionRestApi = 404;
//		}
//
//		timeCheck.timeCheck();
//		timeCheckAPI2.timeCheckAPI2();
//		timeCheckAPI3.timeCheckAPI3();
//
//	}
	}

