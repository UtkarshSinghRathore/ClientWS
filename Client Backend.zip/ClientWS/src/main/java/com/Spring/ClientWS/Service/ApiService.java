package com.Spring.ClientWS.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Spring.ClientWS.ModelClasses.ApisNames;
import com.Spring.ClientWS.TimeRepository.ApisNamesRepo;


@Service
public class ApiService {

	int flag=1;
	@Autowired
	ApisNamesRepo ApiRepo;
	

	// Returns List of all Apis present in the Database
	public List<ApisNames> getAllApis() {
		List<ApisNames> apiList = (List<ApisNames>) ApiRepo.findAll();

		if (apiList.size() > 0) {
			return apiList;
		} else {
			return new ArrayList<ApisNames>();
		}
	}

	// Returns Api with Given Id
	public ApisNames getApisNameById(int id) throws Exception {
		Optional<ApisNames> apinameByid = ApiRepo.findById(id);
		if (apinameByid.isPresent()) {
			return apinameByid.get();
		} else {
			throw new Exception("No Record Found By the ID");
		}

	}

	// Create new Api and Storing in the Database OR Updating the Existing Api
	public ApisNames createorUpdateApis(ApisNames api) {
		Optional<ApisNames> apiNames = ApiRepo.findById(api.getId());

		if (apiNames.isPresent()) {
			ApisNames UpdatedApi = apiNames.get();
			UpdatedApi.setApiName(api.getApiName());
			UpdatedApi.setEndpoint(api.getEndpoint());
			UpdatedApi.setService(api.getService());
			UpdatedApi.setRequest(api.getRequest());
			UpdatedApi.setType(api.getType().toUpperCase());
			UpdatedApi.setResponse(api.getResponse());
			UpdatedApi.setResponseCode(api.getResponseCode());

			UpdatedApi = ApiRepo.save(UpdatedApi);

			return UpdatedApi;
		} else {
			api = ApiRepo.save(api);
			return api;
		}
	}

	// Delete Api with Given ID
	public void deleteApiById(int id) throws Exception {
		Optional<ApisNames> api = ApiRepo.findById(id);

		if (api.isPresent()) {
			ApiRepo.deleteById(id);
		} else
			throw new Exception("No record Found");
	}

	// Returns The List of SOAP Apis
	public List<ApisNames> getSoapServices() throws Exception {
		List<ApisNames> list = (List<ApisNames>) ApiRepo.findAll();
		List<ApisNames> SoapList = new ArrayList<ApisNames>();
		
		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getService().equals("Soap")) {
					SoapList.add(list.get(i));
				}
			}
		} else
			throw new Exception("No Record Found");

		return SoapList;

	}

	// Returns The list of RestAPIs
	public List<ApisNames> getRestServices() throws Exception {
		List<ApisNames> list = (List<ApisNames>) ApiRepo.findAll();
		List<ApisNames> RestList = new ArrayList<ApisNames>();
		System.out.println();
		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getService().equals("Rest")) {
					
					RestList.add(list.get(i));
				}
			}
		} else
			throw new Exception("No Record Found");

		return RestList;

	}
	
	//Update LastUpTime and LastDownTime
	public void UpdateLastTime(ApisNames api) {
		
		
		Optional<ApisNames> apiNames = ApiRepo.findById(api.getId());
		if(apiNames.isPresent()) {
			if(api.getResponseCode()==200) {
				ApisNames UpdatedApi = apiNames.get();
				UpdatedApi.setLast_Uptime(new Date());
				UpdatedApi = ApiRepo.save(UpdatedApi);
			}else {
				if(flag==0) {
					ApisNames UpdatedApi = apiNames.get();
					UpdatedApi.setLast_DownTime(new Date());
					UpdatedApi = ApiRepo.save(UpdatedApi);
					flag=1;
				}
			}
		}
	}

}
