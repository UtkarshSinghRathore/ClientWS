package com.example.spring.Endpoint;

import org.example.loaneligibility.Acknowledgement;
import org.example.loaneligibility.CustomerRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.example.spring.service.LoanEligibiltyService;

@Endpoint
public class LoanEligibiltyEndpoint {

	public static final String NAMESPACE = "http://www.example.org/loanEligibility";
	
	@Autowired
	LoanEligibiltyService service;
	
	@PayloadRoot(namespace = NAMESPACE, localPart = "CustomerRequest")
	@ResponsePayload
	public Acknowledgement getLoan(@RequestPayload CustomerRequest request) {
		return service.misMatchCriteria(request);
	}
}
