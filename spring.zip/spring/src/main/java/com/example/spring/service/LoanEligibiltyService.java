package com.example.spring.service;

import java.util.List;

import org.example.loaneligibility.Acknowledgement;
import org.example.loaneligibility.CustomerRequest;
import org.springframework.stereotype.Service;

@Service
public class LoanEligibiltyService {
	
	public Acknowledgement misMatchCriteria(CustomerRequest request) {
		Acknowledgement acknowledgement = new Acknowledgement();
		
		List<String> misMatchCriteria = acknowledgement.getMisMatchCriteria();
		
		if(!(request.getAge()<30 && request.getAge()<50)) {
		
			misMatchCriteria.add("Age is not Valid");
		}
		if(!(request.getSalary()>10000 && request.getSalary()<50000)) {
			misMatchCriteria.add("Salary is not Valid");
		}
		if(!(request.getCibilScore()>200) && request.getCibilScore()<800) {
			misMatchCriteria.add("Cibil Score is not Valid");
		}
		if(misMatchCriteria.size()>0) {
			acknowledgement.setApprovedAmount(0);
			acknowledgement.setIsEligible(false);
		}
		else {
			acknowledgement.setIsEligible(true);
			acknowledgement.setApprovedAmount(200000);
			misMatchCriteria.clear();
		}
		
		return acknowledgement;
	}

}
