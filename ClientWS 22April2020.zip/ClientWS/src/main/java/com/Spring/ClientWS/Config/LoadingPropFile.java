package com.Spring.ClientWS.Config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:config.properties")
public class LoadingPropFile {

	@Value("${API1_url}")
	public String API1_URL;
	
	@Value("${API2_url}")
	public String API2_URL;
	
	@Value("${API3_url}")
	public String API3_url;

	@Value("${getLimitUrl}")
	public String getLimitUrl;
	
	@Value("${createSessionUrl}")
	public String createSessionUrl;
}

